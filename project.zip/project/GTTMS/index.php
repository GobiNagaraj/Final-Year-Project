<?php 
	header('location: view/home.php');
