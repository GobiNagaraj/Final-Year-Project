<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Image_Home</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/full-slider.css" rel="stylesheet">
    <link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
</head>

<body>
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">Admin Panel</a>
        </div>
        <ul class="nav navbar-nav">
            <li class="active"><a href="image_rotation.php">Home</a></li>
            <li><a class="w3-hover-blue" href="../home/test_map.html">Route</a></li>
            <li><a class="w3-hover-blue" href="../view/route_edit.php">Bus Stop</a></li>
            <li><a class="w3-hover-blue" href="../view/bus_search.php">Bus Search</a></li>
            <li><a class="w3-hover-blue" href="https://www.google.co.in/?gws_rd=ssl#q=sri+shanmugha+college+of+engineering+and+technology">College Details</a></li>            
            <li><a class="w3-hover-blue" href="../view/contact.php">Contact</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
            <li><a class="w3-hover-red" href="admin_login.php"><span class="glyphicon glyphicon-log-out"></span>Log out</a></li>
        </ul>
    </div>
 </nav>

    <header id="myCarousel" class="carousel slide">
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            <li data-target="#myCarousel" data-slide-to="3"></li>
            <li data-target="#myCarousel" data-slide-to="4"></li>
            <li data-target="#myCarousel" data-slide-to="5"></li>
            <li data-target="#myCarousel" data-slide-to="6"></li>
            <li data-target="#myCarousel" data-slide-to="7"></li>
            <li data-target="#myCarousel" data-slide-to="8"></li>
            <li data-target="#myCarousel" data-slide-to="9"></li>
        </ol>

        <div class="carousel-inner">
            <div class="item active">
                <div class="fill" style="background-image:url('image/bus/ams.jpg');"></div>
                <div class="carousel-caption">
                    <h2>Gobi</h2>
                </div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('image/bus/bus7.jpg');"></div>
                <div class="carousel-caption">
                    <h2>Dharun</h2>
                </div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('image/bus/bus8.png');"></div>
                <div class="carousel-caption">
                    <h2>Kavin</h2>
                </div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('image/bus/bus10.jpg');"></div>
                <div class="carousel-caption">
                    <h2>Gobi</h2>
                </div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('image/bus/bus5.jpg');"></div>
                <div class="carousel-caption">
                    <h2>Dharun</h2>
                </div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('image/bus/bus9.jpg');"></div>
                <div class="carousel-caption">
                    <h2>Kavin</h2>
                </div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('image/bus/bus1.jpg');"></div>
                <div class="carousel-caption">
                    <h2>Gobi</h2>
                </div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('image/bus/bus.jpg');"></div>
                <div class="carousel-caption">
                    <h2>Dharun</h2>
                </div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('image/bus/b.jpg');"></div>
                <div class="carousel-caption">
                    <h2>Kavin</h2>
                </div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('image/bus/car.1.jpg');"></div>
                <div class="carousel-caption">
                    <h2>SSCET</h2>
                </div>
            </div>
        </div>

        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="icon-prev"></span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="icon-next"></span>
        </a>

    </header>

    
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
    $('.carousel').carousel({
        interval: 5000 
    })
    </script>

</body>

</html>
