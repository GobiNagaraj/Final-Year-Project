<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Image_Home</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/full-slider.css" rel="stylesheet">
    <link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
    <?php 
    include_once '../model/db.php';
    include_once '../view/header.php';
    ?>
</head>

<body>
    <div class="container">
        <input type="button" name="btn_back" class="btn btn-warning form-control" value="Back" onClick="window.location='../view/home.php';">
    </div><br>
    <header id="myCarousel" class="carousel slide">
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            <li data-target="#myCarousel" data-slide-to="3"></li>
            <li data-target="#myCarousel" data-slide-to="4"></li>
            <li data-target="#myCarousel" data-slide-to="5"></li>
            <li data-target="#myCarousel" data-slide-to="6"></li>
            <li data-target="#myCarousel" data-slide-to="7"></li>
            <li data-target="#myCarousel" data-slide-to="8"></li>
            <li data-target="#myCarousel" data-slide-to="9"></li>
        </ol>

        <div class="carousel-inner">
            <div class="item active">
                <div class="fill" style="background-image:url('image/bus/ams.jpg');"></div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('image/bus/bus7.jpg');"></div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('image/bus/bus8.png');"></div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('image/bus/bus10.jpg');"></div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('image/bus/bus5.jpg');"></div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('image/bus/bus9.jpg');"></div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('image/bus/bus1.jpg');"></div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('image/bus/bus.jpg');"></div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('image/bus/b.jpg');"></div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('image/bus/car.1.jpg');"></div>
            </div>
        </div>

        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="icon-prev"></span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="icon-next"></span>
        </a>

    </header>

    
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
    $('.carousel').carousel({
        interval: 5000 
    })
    </script>

<?php html_footer(); ?>