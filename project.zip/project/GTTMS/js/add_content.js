var couter = 4;
function edit_row(no)
{
 document.getElementById("edit_button"+no).style.display="none";
 document.getElementById("save_button"+no).style.display="block";
	
 var sno=document.getElementById("sno_row"+no);
 var busname=document.getElementById("busname_row"+no);
 var busno=document.getElementById("busno_row"+no);
 var route=document.getElementById("route_row"+no);
 var driver=driver.getElementById("driver_row"+no);
 var start=document.getElementById("start_row"+no);
	
 var sno_data=sno.innerHTML;
 var busname_data=busname.innerHTML;
 var busno_data=busno.innerHTML;
 var route_data=route.innerHTML;
 var driver_data=driver.innerHTML;
 var start_data=start.innerHTML;
	
 sno.innerHTML="<input type='text' id='txt_sno"+no+"' value='"+sno_data+"'>";
 busname.innerHTML="<input type='text' id='txt_busname"+no+"' value='"+busname_data+"'>";
 busno.innerHTML="<input type='text' id='txt_busno"+no+"' value='"+busno_data+"'>";
 route.innerHTML="<input type='text' id='txt_route"+no+"' value='"+route_data+"'>";
 driver.innerHTML="<input type='text' id='txt_driver"+no+"' value='"+driver_data+"'>";
 start.innerHTML="input type='text' id='txt_start"+no+"' value='"+start_data+"'>";
}

function save_row(no)
{
 var sno_val=document.getElementById("txt_sno"+no).value;
 var busname_val=document.getElementById("txt_busname"+no).value;
 var busno_val=document.getElementById("txt_busno"+no).value;
 var route_val=document.getElementById("txt_route"+no).value;
 var driver_val=document.getElementById("txt_driver"+no).value;
 var start_val=document.getElementById("txt_start"+no).value;

 document.getElementById("sno_row"+no).innerHTML=sno_val;
 document.getElementById("busno_row"+no).innerHTML=busno_val;
 document.getElementById("busname_row"+no).innerHTML=busname_val;
 document.getElementById("route_row"+no).innerHTML=route_val;
 document.getElementById("driver_row"+no).innerHTML=driver_val;
 document.getElementById("start_row"+no).innerHTML=start_val;

 document.getElementById("edit_button"+no).style.display="block";
 document.getElementById("save_button"+no).style.display="none";
}

function delete_row(no)
{
 document.getElementById("row"+no+"").outerHTML="";
 couter--;
}


function add_row()
{
 var end = "SSCET";
 var new_sno=document.getElementById("new_sno").value;
 var new_busname=document.getElementById("new_busname").value;
 var new_busno=document.getElementById("new_busno").value;
 var new_route=document.getElementById("new_route").value;
 var new_driver=document.getElementById("new_driver").value;
 var new_start=document.getElementById("new_start").value;

 var table=document.getElementById("data_table");
 var table_len=(table.rows.length)-1;
 var row = table.insertRow(table_len).outerHTML="<tr id='row"+table_len+"'><td id='sno_row"+table_len+"' value='"+couter+"'>"+new_sno+"</td><td id='busname_row"+table_len+"'>"+new_busname+"</td><td id='busno_row"+table_len+"'>"+new_busno+"</td><td id='route_row"+table_len+"'>"+new_route+"</td><td id='driver_row"+table_len+"'>"+new_driver+"</td><td id='start_row"+table_len+"'>"+new_start+"</td><td id='end_row"+table_len+"'>"+end+"</td><td><input type='button' id='edit_button"+table_len+"' value='Edit' class='btn btn-success' onclick='edit_row("+table_len+")'> <input type='button' id='save_button"+table_len+"' value='Save' class='btn btn-info' onclick='save_row("+table_len+")'> <input type='button' value='Delete' class='btn btn-warning' onclick='delete_row("+table_len+")'></td></tr>";

 document.getElementById("new_sno").value=couter;
 document.getElementById("new_busname").value="";
 document.getElementById("new_busno").value="";
 document.getElementById("new_route").value="";
 document.getElementById("new_driver").value="";
 document.getElementById("new_start").value="";
 couter++;
}