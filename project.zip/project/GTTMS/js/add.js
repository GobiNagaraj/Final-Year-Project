$(document).ready(function()
 {
  i=1;
  $('body').on('click', "#btn_Add"+i, function(){
    var x = i+1;
    var end = "SSCET";
    var newTextBoxDiv = $(document.createElement('div')).attr("id",'TextBoxDiv'+x);
    newTextBoxDiv.after().html('<br><table class="table"><tr><td><input type="text" class="form-control transparent-input" id="txt_Sno" placeholder="SNo" style="width:50px;margin-left:0.1px;" value="'+ x +'"></td>'+'<td><input class="form-control transparent-input" type="text" placeholder="Bus Name" name="bus_name[]" id="Bus_Name'+x+'"></td>'+'<td><input class="form-control transparent-input" type="text" name="bus_number[]" id="no_bus_number'+x+'" placeholder="Bus Number" style="margin-left: 5px"></td>'+'<td><input class="form-control transparent-input" type="text" placeholder="Bus Route" name="route[]" id="no_route'+x+'"></td>'+'<td><input class="form-control transparent-input" type="text" name="driver_name[]" id="no_driver_name'+x+'" placeholder="Driver Name" ></td>'+'<td><input class="form-control transparent-input" type="number" name="driver_number[]" id="no_driver_number'+x+'" placeholder="Driver Number" ></td>'+'<td><input class="form-control transparent-input" type="text" name="bus_start[]" id="no_bus_start'+x+'" placeholder="Bus Start"></td>'+'<td><input class="form-control transparent-input" type="text" name="bus_end[]" id="no_bus_end'+x+'" placeholder="'+end+'"></td></tr><table>');                                                                                                                      
    newTextBoxDiv.appendTo("#TextBoxesGroup");
    i++;
    });

$('body').on('click', '#btn_remove', function()
  { 
    if(i==1){
      window.alert("...Admin the content reached End...!");
      $("#btn_Add"+x).show('fast');
      i++;
    }else{
       $('#TextBoxDiv'+i).remove();
      i--;
      $("#btn_Add"+i).show('fast');
    }    
  });

});
