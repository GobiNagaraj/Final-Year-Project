<?php 
	include_once 'header.php';
	html_header("Home Page");
 ?>
 <head>
 	<link rel="stylesheet" type="text/css" href="../css/first.css" />
 	<style type="text/css">
 		label
 		{
 			color: #1d6909;
 			font-style: italic;
 		}
 		h1
 		{
 			color: #030efc;
 			font-size: 40px;
 		}
 	</style>
 </head>
 <!-- <body background="../pages/image/bus/bus5.jpg"></body> -->
 <body background="../pages/image/bus/photo1.jpg" style="background-repeat: no-repeat;">
 <h1><b><center><i>Global Transport Tracking and Messaging System</i></center></b></h1>
 </body>

<div id="container">
	<header>
	  <hgroup>
	    <h1><a href="admin_login.php"><label>Admin User</label></a></h1>
	  </hgroup>
	</header>
    <div id="menu">
	  <nav>
	  <ul>
		  <span class="navbefore"></span>
			  <li class="menu-item"><a href="../pages/user_home.php">Home</a></li>
			  <li class="menu-item"><a href="../home/test_map.html">Route</a></li>
			  <li class="menu-item"><a href="../home/bus_search.php">Bus Stop</a></li>
			  <li class="menu-item"><a href="../home/bus_college_details.php">College Details</a></li>
			  <li class="menu-item"><a href="http://shanmugha.edu.in/?page_id=778">Contact</a></li>		
			  <li class="menu-item noHover"><a href="#">.</a></li>
		  <span class="navafter"></span>
	  </ul>
	  </nav>
    </div>
    <br>
    <!-- <div style="margin-left: 250px">
    <img src="../images/back5.jpg" alt="" class="left" style=" width: 400px; height: 300px; ">
    <img src="../images/back4.jpg" alt="" class="right">
    </div> -->
 </div>

<?php html_footer();?>