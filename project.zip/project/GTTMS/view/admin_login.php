<?php 
	session_start();
	include_once 'header.php';
	html_header("Admin Login");
	session_destroy();
 ?>
	<div class="container">
		<?php 
		if(isset($_GET['status']))
		{
			switch ($_GET['status']) 
			{
				case 'Admin_Error':
					echo "<div class='alert alert-danger'>Admin name or Password is incorrect</div>";
					break;
			}
		}		
	 ?>
		<h1 style="text-align: center;">Admin Login</h1>
		<form method="POST" action="../controller/admin_login_controller.php">
			<input type="text" name="admin_name" class="form-control" placeholder="Admin Name" required ><br/>
			<input type="password" name="admin_password" class="form-control" placeholder="Admin Password" required><br/>
			<input type="submit" name="submit" class="btn btn-success" value="Login" style="width: 580px;">
			&nbsp;
			<input type="reset" name="reset" class="btn btn-primary" value="Go to Home Page" onClick="window.location='../view/home.php';" style="width: 544px;">
		</form>
	</div>
<?php html_footer();?>