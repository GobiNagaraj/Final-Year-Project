<?php 
	session_start();
	include_once 'header.php';
	html_header("Route Edit");
 ?>
 <nav class="navbar navbar-inverse">
 	<div class="container-fluid">
 		<div class="navbar-header">
 			<a class="navbar-brand" href="#">Admin Panel</a>
 		</div>
 		<form method="REQUEST" action="search.php">
 			<ul class="nav navbar-nav">
	 			<li><a class="w3-hover-blue" href="../pages/index.php">Home</a></li>
	 			<li><a class="w3-hover-blue" href="../home/admin_map.html">Route</a></li>
	 			<li class="active"><a class="w3-hover-blue" href="route_edit.php">Bus Stop</a></li>
	 			<li><a class="w3-hover-blue" href="bus_search.php">Bus Search</a></li>
	 			<li><a class="w3-hover-blue" href="http://shanmugha.edu.in/">College Details</a></li> 
	 			<li><a class="w3-hover-blue" href="contact.php">Contact</a></li>
	 			<li><input type="text" name="search" class="form-control" placeholder="Search" required></li>
	 			<li><button type="submit" class="btn btn-primary">Search</button></li>
 			</ul>
 		</form>

 		<ul class="nav navbar-nav navbar-right">
 			<li><a class="w3-hover-red" href="admin_login.php"><span class="glyphicon glyphicon-log-out"></span>Log out</a></li>
 		</ul>
 	</div>
 </nav>
 <form method="POST" action="../controller/route_edit_controller.php" id="mainform">
 	<div id="TextBoxesGroup">
 		<table class="table">
 			<tr>
 				<td>S.No</td>
 				<td>Bus Name</td>
 				<td>Bus Number</td>
 				<td>Route</td>
 				<td>Driver Name</td>
 				<td>Driver Number</td>
 				<td>Start</td>
 				<td>End</td>
 			</tr>
 			<tr>
 				<td>
 					<input type="text" class="form-control transparent-input" id="txt_Sno" placeholder="SNo" value="1" style="width:50px" required="required" >
				</td>
				<td>
					<input type="text" class="form-control transparent-input" name="bus_name[]"   id="no_bus_name1" placeholder="Bus Name" required="required" >
				</td>
				<td>
					<input class="form-control transparent-input" type="text" name="bus_number[]" id="no_bus_number1" placeholder="Bus Number" required="required" >
				</td>
				<td>
					<input class="form-control transparent-input" type="text" name="route[]" id="no_route1" placeholder="Bus Route" required="required" >
				</td>
				<td>
					<input class="form-control transparent-input" type="text" name="driver_name[]" id="no_driver_name1" placeholder="Driver Name" required="required" >
				</td>
				<td>
					<input class="form-control transparent-input" type="number" name="driver_number[]" id="no_driver_number1" placeholder="Driver Number" required="required" >
				</td>
				<td>
					<input class="form-control transparent-input" type="text" name="bus_start[]" id="no_bus_start1" placeholder="Started" required="required" >
				</td>
				<td>
					<input class="form-control transparent-input" type="text" name="bus_end[]" id="no_bus_end1" placeholder="End" required="required" >
				</td>
			</tr>
 		</table>
 	</div>
	 <div class="btn-group btn-group-justified">
	 	<div class="btn-group">
	 		<input type="button" name="add_details" class="btn btn-primary" value="Add" id="btn_Add1">
	 	</div>
	 	<div class="btn-group">
	 		<input type="button" name="remove_details" class="btn btn-primary" value="Delete" id="btn_remove">
	 	</div>
	 	<div class="btn-group">
	 		<input type="submit" name="submit" class="btn btn-primary" value="Save" id="btn_save">
	 	</div>
	 </div>
</form>


 <?php html_footer();?>