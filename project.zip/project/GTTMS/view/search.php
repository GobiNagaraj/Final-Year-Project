<?php 
	session_start();
	include_once '../model/db.php';
	include_once 'header.php';
	html_header("Bus Search");
	// print_r($_REQUEST);
	$connection = db_connect();
	$sql = "SELECT * FROM `route_edit` WHERE `route` LIKE '".$_REQUEST['search']."'";	
	$result = execute_query($connection,$sql);
 ?>
<nav class="navbar navbar-inverse">
 	<div class="container-fluid">
 		<div class="navbar-header">
 			<a class="navbar-brand" href="#">Admin Panel</a>
 		</div>
 		<form method="REQUEST" action="search.php">
 			<ul class="nav navbar-nav">
	 			<li><a class="w3-hover-blue" href="../pages/index.php">Home</a></li>
	 			<li><a class="w3-hover-blue" href="../home/admin_map.html">Route</a></li>
	 			<li><a class="w3-hover-blue" href="route_edit.php">Bus Stop</a></li>
	 			<li><a class="w3-hover-blue" href="bus_search.php">Bus Search</a></li>
	 			<li><a class="w3-hover-blue" href="http://shanmugha.edu.in/">College Details</a></li> 
	 			<li><a class="w3-hover-blue" href="contact.php">Contact</a></li>
	 			<li class="active"><input type="text" name="search" class="form-control" placeholder="Search" required></li>
	 			<li><button type="submit" class="btn btn-primary">Search</button></li>
 			</ul>
 		</form>

 		<ul class="nav navbar-nav navbar-right">
 			<li><a class="w3-hover-red" href="admin_login.php"><span class="glyphicon glyphicon-log-out"></span>Log out</a></li>
 		</ul>
 	</div>
 </nav>
 		<table class="table">
 			<tr>
 				<th>Bus Name</th>
 				<th>Bus Number</th>
 				<th>Route</th>
 				<th>Driver Name</th>
 				<th>Driver Number</th>
 				<th>Start</th>
 			</tr>
 			<?php 
 				if (empty($result)) {
					echo "NO details";
			}
	else{
		while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
 					echo "<tr>";
 					echo '<td>'.$row['bus_name'].'</td>';
 					echo '<td>'.$row['bus_number'].'</td>';
 					echo '<td>'.$row['route'].'</td>';
 					echo '<td>'.$row['driver_name'].'</td>';
 					echo '<td>'.$row['driver_number'].'</td>';
 					echo '<td>'.$row['bus_start'].'</td>';
 					echo "</tr>";
 				}
 		}
 			 ?>
 		</table>
 	
<?php html_footer();?>
