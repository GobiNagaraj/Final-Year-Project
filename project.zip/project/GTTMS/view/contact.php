<?php 
	session_start();
	include_once 'header.php';
	html_header("Route");
 ?>
 <nav class="navbar navbar-inverse">
 	<div class="container-fluid">
 		<div class="navbar-header">
 			<a class="navbar-brand" href="#">Admin Panel</a>
 		</div>
 		<form method="REQUEST" action="search.php">
 			<ul class="nav navbar-nav">
	 			<li><a class="w3-hover-blue" href="../pages/index.php">Home</a></li>
	 			<li><a class="w3-hover-blue" href="../home/admin_map.html">Route</a></li>
	 			<li><a class="w3-hover-blue" href="route_edit.php">Bus Stop</a></li>
	 			<li><a class="w3-hover-blue" href="bus_search.php">Bus Search</a></li>
	 			<li><a class="w3-hover-blue" href="http://shanmugha.edu.in/">College Details</a></li> 
	 			<li class="active"><a class="w3-hover-blue" href="contact.php">Contact</a></li>
	 			<li><input type="text" name="search" class="form-control" placeholder="Search" required></li>
	 			<li><button type="submit" class="btn btn-primary">Search</button></li>
 			</ul>
 		</form>

 		<ul class="nav navbar-nav navbar-right">
 			<li><a class="w3-hover-red" href="admin_login.php"><span class="glyphicon glyphicon-log-out"></span>Log out</a></li>
 		</ul>
 	</div>
 </nav>

	<h1><center><b><i>Dharun Kumar. S</i></b></center></h1>
	<h3><center><b><i>+91- 8015238696</i></b></center></h3>
	<hr>
	<h1><center><b><i>Gobi. N</i></b></center></h1>
	<h3><center><b><i>+91- 9043808501</i></b></center></h3>
	<hr>
	<h1><center><b><i>Kavin Kumar. P</i></b></center></h1>
	<h3><center><b><i>+91- 9524420673</i></b></center></h3>
	<hr>
<?php html_footer();?>