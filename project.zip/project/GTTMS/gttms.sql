-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2017 at 10:24 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gttms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(255) NOT NULL,
  `admin_name` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin_name`, `admin_password`) VALUES
(1, 'gobi', 'gobi@123'),
(3, 'Dharun', 'dharun@123'),
(4, 'Kavin', 'kavin@123');

-- --------------------------------------------------------

--
-- Table structure for table `route_edit`
--

CREATE TABLE `route_edit` (
  `id` int(255) NOT NULL,
  `bus_name` varchar(255) NOT NULL,
  `bus_number` varchar(255) NOT NULL,
  `route` text NOT NULL,
  `driver_name` varchar(255) NOT NULL,
  `driver_number` bigint(255) NOT NULL,
  `bus_start` text NOT NULL,
  `bus_end` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `route_edit`
--

INSERT INTO `route_edit` (`id`, `bus_name`, `bus_number`, `route`, `driver_name`, `driver_number`, `bus_start`, `bus_end`) VALUES
(1, '11', 'TN 32 X 4069', 'Erode', 'GObi', 9043808501, 'bus stand ', 'sscet'),
(2, '7', 'TN 47 Z 2710', 'T.gode', 'Kavin', 9543366958, 'veppadai', 'sscet'),
(3, '15', 'TN 34 M 7085', 'Erode', 'go', 9788387983, 'naal road', 'sscet'),
(4, '13', 'TN 32 X 7777', 'sankari', 'dharun', 9043462865, 'salem', 'sscet'),
(5, '10', 'TN 34 X 9011', 'salem', 'jack', 9874563210, 'bus stand ', 'sscet');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `route_edit`
--
ALTER TABLE `route_edit`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `route_edit`
--
ALTER TABLE `route_edit`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
