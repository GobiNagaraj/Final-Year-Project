<?php 
	include_once '../model/db.php';
	include_once '../view/header.php';
	html_header("Single Bus Search");
	// print_r($_REQUEST);
	$connection = db_connect();
	$sql = "SELECT * FROM `route_edit` WHERE `route` LIKE '".$_REQUEST['search']."'";	
	$result = execute_query($connection,$sql);
 ?>
 	<br><center><input type="button" name="btn_back" class="btn btn-warning" style="width: 500px;" value="Back" onClick="window.location='../view/home.php';"></center><br><br>
 		<table class="table">
 			<tr>
 				<th>Bus Name</th>
 				<th>Bus Number</th>
 				<th>Route</th>
 				<th>Driver Name</th>
 				<th>Driver Number</th>
 				<th>Start</th>
 			</tr>
 			<?php 
 					if (empty($result)) {
		echo "NO details";
	}
	else{
		while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
		//print_r($row);
 					echo "<tr>";
 					//echo '<td>'.$row['id'].'</td>';
 					echo '<td>'.$row['bus_name'].'</td>';
 					echo '<td>'.$row['bus_number'].'</td>';
 					echo '<td>'.$row['route'].'</td>';
 					echo '<td>'.$row['driver_name'].'</td>';
 					echo '<td>'.$row['driver_number'].'</td>';
 					echo '<td>'.$row['bus_start'].'</td>';
 					//echo '<td>'.$row['bus_end'].'</td>';
 					echo "</tr>";
 				}
 		}
 			 ?>
 		</table>
 	
<?php html_footer();?>
