<!DOCTYPE html>
<html>
<head>
	<title>College Details</title>
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
	<script type="text/javascript" src="../bootstrap/js/bootstrap.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="../js/add.js" type="text/javascript"></script>
</head>
<body>
	<h1><center><b><a href="http://shanmugha.edu.in/">click here</a></b></center></h1>
	<br>
	<div class="container">
		<input type="button" name="btn_back" class="btn btn-warning form-control" value="Back" onClick="window.location='../view/home.php';">
	</div>
</body>
</html>