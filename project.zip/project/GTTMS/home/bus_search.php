<!DOCTYPE html>
<html>
<head>
	<title>Bus Search</title>
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
	<script type="text/javascript" src="../bootstrap/js/bootstrap.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="../js/add.js" type="text/javascript"></script>
</head>
<body>
<?php 
	include_once '../model/db.php';
	include_once '../view/header.php';
	$connection = db_connect();
	//$sel = "SELECT `id`, `bus_name`, `bus_number`, `route`, `driver_name`, `bus_start`, `bus_end` FROM `route_edit`";
	$sel = "SELECT * FROM `route_edit`";
	$result = execute_query($connection,$sel);
 ?>
 <form method="POST" action="single_bus_search.php">
 	<br><table width="100%">
 		<tr>
 			<td><input type="text" name="search" class="form-control" style="width: 650px;" placeholder="Search"></td>
 			<td><button type="submit" class="btn btn-primary" style="width: 700px;" >Search</button></td>
 		</tr>
 	</table><br>
 </form>
 		<table class="table">
 			<tr>
 				<th>S.No</th>
 				<th>Bus Name</th>
 				<th>Bus Number</th>
 				<th>Route</th>
 				<th>Driver Name</th>
 				<th>Driver Number</th>
 				<th>Start</th>
 				<th>End</th>
 			</tr>
 			<?php 
 				while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)) {
 					echo "<tr>";
 					echo '<td>'.$row['id'].'</td>';
 					echo '<td>'.$row['bus_name'].'</td>';
 					echo '<td>'.$row['bus_number'].'</td>';
 					echo '<td>'.$row['route'].'</td>';
 					echo '<td>'.$row['driver_name'].'</td>';
 					echo '<td>'.$row['driver_number'].'</td>';
 					echo '<td>'.$row['bus_start'].'</td>';
 					echo '<td>'.$row['bus_end'].'</td>';
 					echo "</tr>";
 				}
 			 ?>
 		</table>

 		<br>
	<div class="container">
		<input type="button" name="btn_back" class="btn btn-warning form-control" value="Back" onClick="window.location='../view/home.php';">
	</div>

<?php html_footer();?>
