<!DOCTYPE html>
<html>
<head>
	<title>Contact Details</title>
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
	<script type="text/javascript" src="../bootstrap/js/bootstrap.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="../js/add.js" type="text/javascript"></script>
</head>
<body>
	<h1><center><b><i>Dharun Kumar. S</i></b></center></h1>
	<h3><center><b><i>+91- 8015238696</i></b></center></h3>
	<hr>
	<h1><center><b><i>Gobi. N</i></b></center></h1>
	<h3><center><b><i>+91- 9043808501</i></b></center></h3>
	<hr>
	<h1><center><b><i>Kavin Kumar. P</i></b></center></h1>
	<h3><center><b><i>+91- 9524420673</i></b></center></h3>
	<hr>
	<br>
	<div class="container">
		<input type="button" name="btn_back" class="btn btn-warning form-control" value="Back" onClick="window.location='../view/home.php';">
	</div>

<?php html_footer(); ?>