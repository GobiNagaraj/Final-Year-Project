<!DOCTYPE html>
<html>
<head>
	<title>Bus Route</title>
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
	<script type="text/javascript" src="../bootstrap/js/bootstrap.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="../js/add.js" type="text/javascript"></script>
</head>
<body>
	<img src="../images/shan_route.jpg" style="margin-left: 10px" width="520px" height="395px" >
	<img src="../images/shan_route2.jpg"  width="520px" height="395px"><br>
	<div class="container">
		<input type="button" name="btn_back" class="btn btn-warning form-control" value="Back" onClick="window.location='../view/home.php';">
	</div>

</body>
</html>