<?php 
	
	include_once '../model/db.php';

	session_start();
	echo "<pre>";
	print_r($_SESSION);
	print_r($_REQUEST);
	echo "</pre>";
	$name = $_REQUEST['admin_name'];
	$password = $_REQUEST['admin_password'];
	

	$connection = db_connect();
	$sql = "SELECT * FROM `admin` WHERE `admin_name`='".$name."' AND `admin_password`= '".$password."'";
	echo $sql;
	$result = execute_query($connection,$sql);
	$user_data = mysqli_fetch_array($result,MYSQLI_ASSOC);

	if (empty($user_data)) {
		header('Location:../view/admin_login.php?status=Admin_Error');
	}
	else{
		$_SESSION['user_data'] = $user_data;
		header('Location:../view/admin_control.php');
	}

 ?>