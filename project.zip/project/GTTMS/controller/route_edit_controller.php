<?php 
	session_start();
	include_once '../model/db.php';
	echo "<pre>";
	print_r($_SESSION);
	print_r($_REQUEST);
	$connection = db_connect();
	$cont=0;
	$j=0;
	foreach ($_REQUEST['bus_name'] as $value) {
		$cont++;
	}
	for ($i=0; $i < $cont; $i++) { 
	$sql = "INSERT INTO `route_edit` (`bus_name`, `bus_number`, `route`, `driver_name`,`driver_number`, `bus_start`, `bus_end`) VALUES ('".$_REQUEST['bus_name'][$i]."','".$_REQUEST['bus_number'][$i]."','".$_REQUEST['route'][$i]."','".$_REQUEST['driver_name'][$i]."','".$_REQUEST['driver_number'][$i]."','".$_REQUEST['bus_start'][$i]."','".$_REQUEST['bus_end'][$i]."') ";
	execute_query($connection,$sql);
	$j++;
	}
	if (!empty($j)) {
		//print_r($sql);
		//echo "Data Entered Successfully";
		header('Location:../view/bus_search.php');
	}
	else{
		header('Location:../view/route_edit.php?status=Error');
	}

?>