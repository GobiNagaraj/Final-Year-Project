<?php 
	
	function db_connect()
	{
		$hostname = "localhost";
		$username = "root";
		$password = "";
		$conn = mysqli_connect($hostname, $username, $password,"gttms");
		return $conn;
	}

	function execute_query($conn,$query)
	{
		return mysqli_query($conn,$query);
	}

?>